Chapter 4 and 5:
Does not have code: These chapters are validation and packaging steps
that are applied to chapter 3's code pack