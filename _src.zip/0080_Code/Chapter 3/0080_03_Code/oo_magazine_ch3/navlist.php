<div id="intTop_navlist">
<h2>main navigation</h2>
<!--//start page nav list-->
<ul id="navlist">
   <li class="current_page_item"><a href="/">The Zine</a></li>
   <?php //wp_list_pages(); 
         wp_list_pages('title_li=' ); ?>
</ul>
<!--//end page nav list-->
</div><!--//top_navlist-->