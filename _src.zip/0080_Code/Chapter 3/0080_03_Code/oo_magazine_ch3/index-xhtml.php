<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<title>OpenSource Online Magazine - In WordPress</title>

<script type="text/javascript" src=""></script>
<style type="text/css" media="screen">

@import url("<?php bloginfo("stylesheet_url"); ?>");
        
</style>

</head>

<body>
<a name="top"></a><!--anchor for top-->
<div id="container"><!--container goes here-->
<div id="header">
<h1>OpenSource Online Magazine</h1>
<p><em>Using Open Source for work and play</em></p>
<div id="date">Current Month and Year</div>
</div><!--//header-->

<!-- Begin #container2 this holds the content and sidebars-->
<div id="container2">

<!-- Begin #container3 keeps the left col and body positioned-->
<div id="container3">
<!-- Begin #content -->
<div id="content">
<h2 class="thisMonth">This Month</h2>
<h2><a href="#">Really Long Article Title Name The More Text The Better Cause You Never Know</a></h2>

<p>by Author Name for <a href="#">Column Type</a></p>

<div><!--//post-->
<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Sed a eros nec orci volutpat vestibulum. Ut pellentesque sagittis metus. In euismod tellus id ante. Ut lectus. Nunc adipiscing. Praesent luctus, massa quis vulputate rhoncus, justo turpis mollis dolor, nec blandit nisl mauris et pede.</p> 
<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Sed a eros nec orci volutpat vestibulum. Ut pellentesque sagittis metus.</p>  

<p><a href="#">Read the rest of this entry &raquo;</a></p>
</div><!--//post-->

<div class="comments"><div class="commentIcon">No Comments</div> <a href="#">Add Your Thoughts</a></div>

</div><!-- //content -->

<!-- #left sidebar -->
<div id="sidebarLT">
<h2 class="features">Features</h2>
<ul class="tocNav">
<li><a href="#">Article Name 01 Lorem ipsum dolor sit amet consectetuer adipiscing elit</a></li>
<li><a href="#">Article Name 02 Lorem ipsum dolor sit amet</a></li>
<li><a href="#">Article Name 03 Lorem ipsum</a></li>
</ul>

<h2 class="columns">Columns</h2>
<ul class="tocNav">
<li><a href="#">Name of Category 01 Lorem ipsum (#)</a></li>
<li><a href="#">Name of Category 02 Lorem (#)</a></li>
<li><a href="#">Name of Category 03 Lorem ipsum dolor (#)</a></li>
</ul>

<h2 class="pastIssues">Past Issues</h2>
<ul class="tocNav">
<li><a href="#">Archive Link year/month 01</a></li>
<li><a href="#">Archive Link year/month 02</a></li>
<li><a href="#">Archive Link year/month 03</a></li>
</ul>
</div><!--//sidebarLT  -->
</div><!--//container3-->

<!-- #right sidebar -->
<div id="sidebarRT">
<div>Key BlockQuotes, <br/>links, <br/>ads or other items.</div>
</div><!--//sidebarRT --> 

<div id="pushbottom"> </div><!--//this div will span across the 3 divs above it making sure the footer stays at the bottom of the longest column-->

</div><!--//container2-->

<div id="top_navlist">
<h2>main navigation</h2>
<ul id="navlist">
<li class="current_page_item"><a href="#">The OO Zine</a></li>
<li><a href="#">About Us</a></li>
<li><a href="#">References</a></li>
<li><a href="#">Contact</a></li>
</ul>
</div><!--//top_navlist-->

<div id="footer">

<div id="footerRight">
<h3>Footer Information</h3>
<p>
<a href="#">link 01</a> | 
<a href="#">link 02</a> | 
<a href="#">link 03</a> | 
<a href="#">link 04</a> | 

<a href="#">link 05</a><br />

</p>
</div><!--//footerRight-->

<div id="footerLeft">
<p>
		OpenSource Online Magazine is proudly powered by
		<a href="http://wordpress.org/">WordPress</a>

</p>
</div><!--//footerLeft-->

</div><!--//footer-->


</div><!--//container-->

</body>

</html>