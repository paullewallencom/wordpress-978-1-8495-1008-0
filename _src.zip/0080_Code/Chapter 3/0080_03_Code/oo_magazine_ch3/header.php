<?php include(TEMPLATEPATH . '/head-meta.php'); ?>

<body>
<a name="top"></a><!--anchor for top-->
<div id="container"><!--container goes here-->
<div id="intHeader">
<h1>OpenSource Online Magazine</h1>
<p><em>Using Open Source for work and play</em></p>
<div id="date"><?php echo date("F Y"); ?></div>

</div><!--//header-->

