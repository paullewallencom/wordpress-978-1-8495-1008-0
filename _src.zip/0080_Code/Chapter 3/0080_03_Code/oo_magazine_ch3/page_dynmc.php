<?php
/*
Template Name: Dynamic Page
*/
?>

<?php get_header(); ?>

<div id="content" class="widecolumn">

<h2>Links:</h2>
<ul>
<?php get_links_list(); ?>
</ul>

</div>

<?php get_footer(); ?>
