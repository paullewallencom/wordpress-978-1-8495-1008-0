<div id="sidebar2">


<?php if ( !function_exists('dynamic_sidebar')
        || !dynamic_sidebar() ) : ?>
<p><b>This sidebar is Widgetized!</b><br/>
Add items via <em>Admin>Design>Widgets</em></p>
<?php endif; ?>

<br/>

<div class="roundedCorner">
This is a div with CSS3 rounded Corners.
</div>

<div class="fakeSidebar">

<?php 
/*enter your google AdWords or AdBright or other
Associate link info here and remove the background
url from #sidbar2 in the style.css sheet*/
?>


</div><!--//end fakeSidebar-->

</div><!--//sidebar2-->